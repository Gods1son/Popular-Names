﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections.ObjectModel;


namespace Name_search
{
    class VM : INotifyPropertyChanged
    {
        public string Input
        {
            get { return _input; }
            set { _input = value; OnPropertyChanged(); }
        }
        private string _input;
        public ObservableCollection<string> Output
        {
            get { return _output; }
            set { _output = value; OnPropertyChanged(); }
        }
        ObservableCollection<string> _output = new ObservableCollection<string>();
    
        public void Work()
        {
            string [] Boy = File.ReadAllLines("BoyNames.txt");
            string [] Girl = File.ReadAllLines("GirlNames.txt");
            string[] combinedName = Boy.Concat(Girl).ToArray();
            Array.Sort(combinedName);
            string[] lower = combinedName.Select(s => s.ToLowerInvariant()).ToArray();
            ////////
          //  string[] name = new string[500];
            string [] name = Input.Split(',');
            for (int i = 0; i < name.Length; i++)
            {
                int Result = Array.BinarySearch(lower, name[i].ToLower());
                if (Result > 0)
                {
                    Output.Add("The most popular list of names contains " + name[i]);
                }
                else Output.Add("The most popular list of names does not contain " + name[i]);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName]string caller = null)
        {
            // make sure only to call this if the value actually changes
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(caller));
            }
        }
    }
}
